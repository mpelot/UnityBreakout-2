CONTROLS:
A and D - move left and right
SPACE   - jump, hold to jump higher